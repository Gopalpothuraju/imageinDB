package com.pennant.ems.operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.pennant.ems.connection.DBConnection;

/**
 * Servlet implementation class UpdateEmployee
 */
@WebServlet("/UpdateEmployee")
@MultipartConfig
public class UpdateEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
   Connection con=null;
	public void init(ServletConfig config) throws ServletException {
	con=DBConnection.getConnectToDb();
	}
	public void destroy() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			 response.setContentType("text/html;charset=UTF-8");
			int empId = Integer.parseInt(request.getParameter("empid"));
			String empName = request.getParameter("name");
			String role = request.getParameter("role");
			double salary = Double.parseDouble(request.getParameter("salary"));
			String dob = request.getParameter("doj");
			String email = request.getParameter("ename");
			String mobile = request.getParameter("mobile");
			  Part p =  request.getPart("pic");
			
			PreparedStatement pst = con.prepareStatement("update employee_management_system set emp_name=?, emp_role=?,emp_salary=?,emp_profile_image=?,emp_mobile=?,emp_mail=?,dob=? where emp_id=?");
			pst.setString(1, empName);
			pst.setString(2, role);
			pst.setDouble(3, salary);
			pst.setBinaryStream(4, p.getInputStream(), (int)  p.getSize());
			pst.setString(5, mobile);
			pst.setString(6, email);
			pst.setDate(7, Date.valueOf(dob));
			pst.setInt(8, empId);
			int i = pst.executeUpdate();
			if(i>0){
				 response.sendRedirect("RetrieveEmployee");
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
