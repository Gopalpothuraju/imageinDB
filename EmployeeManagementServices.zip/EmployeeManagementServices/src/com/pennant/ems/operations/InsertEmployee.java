package com.pennant.ems.operations;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.pennant.ems.connection.DBConnection;

@WebServlet("/InsertEmployee")
@MultipartConfig
public class InsertEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
   Connection con=null;
	public void init(ServletConfig config) throws ServletException {
		con=DBConnection.getConnectToDb();
	}

	public void destroy() {
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html;charset=UTF-8");
		String name=request.getParameter("name"); 
		String email = request.getParameter("email");
		 String password = request.getParameter("password");
		 String role = request.getParameter("role");
		 String mobile = request.getParameter("mobile");
		 String date = request.getParameter("doj");
		 Part photo =  request.getPart("pic");  
		 Double salary=0.0;
		

		 if(role.equals("admin")){
			 salary=11000.00;
		 }else if(role.equalsIgnoreCase("tester")){
			 salary=12000.00;
		 }else{
			 salary=15000.00;
		 }
		 try {
			PreparedStatement pst = con.prepareStatement("insert into EMPLOYEE_MANAGEMENT_SYSTEM values(emp_id.nextval,?,?,?,?,?,?,?,?)");
			pst.setString(1, name);
			pst.setString(2, role);
			pst.setDouble(3, salary);
			pst.setBinaryStream(4, photo.getInputStream(), (int)  photo.getSize());
			pst.setString(5, mobile);
			pst.setString(6, email);
			pst.setDate(7, Date.valueOf(date));
			pst.setString(8, password);
			int i = pst.executeUpdate();
			if(i>0){
				response.sendRedirect("RetrieveEmployee");
			}
		 } catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 
	}

}
